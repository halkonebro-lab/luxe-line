# Luxe_line_2 v3 — Public Premium Store

Version améliorée de la boutique Luxe_line_2 avec storefront public et espace administration.

## Admin
- URL: `/#admin`
- Identifiant par défaut: `admin`
- Mot de passe par défaut: `ChangeMe123!`
- En production, définir `ADMIN_USER`, `ADMIN_PASS` et `JWT_SECRET`.

## Gestion produits
Depuis Admin > Produits:
- ajouter un produit
- modifier nom, marque, catégorie, prix, ancien prix, stock, description
- URL d'image ou upload direct
- activer/désactiver Best seller
- supprimer

## Commandes
Voir les commandes et changer leur statut.

## Déploiement Render
Build: `npm install`
Start: `npm start`

Variables:
`ADMIN_USER`, `ADMIN_PASS`, `JWT_SECRET`, `DATA_DIR`, `UPLOAD_DIR`.

Note: le stockage local d'un service Render gratuit est éphémère; un disque persistant est payant. 
