
const express = require('express');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const multer = require('multer');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_THIS_SECRET';
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || 'ChangeMe123!';

const dataDir = process.env.DATA_DIR || path.join(__dirname, 'data');
const uploadDir = process.env.UPLOAD_DIR || path.join(__dirname, 'public', 'uploads');
fs.mkdirSync(dataDir, {recursive:true});
fs.mkdirSync(uploadDir, {recursive:true});

const db = new Database(path.join(dataDir, 'luxe.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS products(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL, brand TEXT DEFAULT '', category TEXT DEFAULT 'Maquillage',
 price REAL NOT NULL, old_price REAL DEFAULT 0, stock INTEGER DEFAULT 0,
 description TEXT DEFAULT '', image TEXT DEFAULT '', featured INTEGER DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 customer_name TEXT NOT NULL, phone TEXT NOT NULL, address TEXT NOT NULL, city TEXT NOT NULL,
 delivery TEXT DEFAULT 'Standard', payment TEXT DEFAULT 'COD', items TEXT NOT NULL,
 total REAL NOT NULL, status TEXT DEFAULT 'new', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS settings(
 key TEXT PRIMARY KEY, value TEXT
);
`);

const count = db.prepare('SELECT COUNT(*) c FROM products').get().c;
if (!count) {
  const seed = db.prepare(`INSERT INTO products(name,brand,category,price,old_price,stock,description,image,featured)
    VALUES(?,?,?,?,?,?,?,?,?)`);
  [
    ['Velvet Nude Lip','Luxe Line','Maquillage',129,159,12,'Rouge à lèvres fini velours, teinte nude élégante.','https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=900&q=85',1],
    ['Glow Skin Serum','Luxe Line','Skincare',179,219,9,'Sérum éclat pour une routine beauté lumineuse.','https://images.unsplash.com/photo-1611930022073-b7a4ba5fcccd?auto=format&fit=crop&w=900&q=85',1],
    ['Eau de Parfum Rose','Luxe Line','Parfums',249,299,8,'Parfum floral féminin au sillage doux et sophistiqué.','https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=900&q=85',1],
    ['Silk Hair Mist','Luxe Line','Cheveux',149,0,15,'Brume légère pour cheveux avec fini soyeux.','https://images.unsplash.com/photo-1522338242992-e1a54906a8da?auto=format&fit=crop&w=900&q=85',0],
    ['Soft Blush','Luxe Line','Maquillage',119,139,20,'Blush naturel pour une touche fraîche et lumineuse.','https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=900&q=85',1],
    ['Hydra Cream','Luxe Line','Skincare',159,0,14,'Crème hydratante quotidienne à texture confortable.','https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=900&q=85',0]
  ].forEach(p=>seed.run(...p));
}
const defaults = {
  store_name:'Luxe_line_2', phone:'0703676862', whatsapp:'212703676862',
  address:'Gueznaia, Tanger', delivery_note:'Livraison à Tanger et alentours'
};
for (const [k,v] of Object.entries(defaults))
  db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k,v);

app.use(express.json({limit:'2mb'}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname,'public')));

const upload = multer({dest: uploadDir});
function auth(req,res,next){
  const h=req.headers.authorization||'';
  if(!h.startsWith('Bearer ')) return res.status(401).json({error:'Unauthorized'});
  try { req.admin=jwt.verify(h.slice(7),JWT_SECRET); next(); }
  catch(e){ res.status(401).json({error:'Unauthorized'}); }
}
function settings(){
  return Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map(x=>[x.key,x.value]));
}

app.get('/api/store',(req,res)=>res.json(settings()));
app.get('/api/products',(req,res)=>{
  const {category,search,sort,featured}=req.query;
  let sql='SELECT * FROM products WHERE 1=1', params={};
  if(category && category!=='Tous'){sql+=' AND category=@category';params.category=category}
  if(search){sql+=' AND (name LIKE @search OR brand LIKE @search OR description LIKE @search)';params.search='%'+search+'%'}
  if(featured==='1') sql+=' AND featured=1';
  sql += sort==='price-asc'?' ORDER BY price ASC':sort==='price-desc'?' ORDER BY price DESC':' ORDER BY featured DESC, id DESC';
  res.json(db.prepare(sql).all(params));
});
app.post('/api/orders',(req,res)=>{
  const {customer_name,phone,address,city,delivery,payment,items,total}=req.body;
  if(!customer_name||!phone||!address||!city||!Array.isArray(items)||!items.length) return res.status(400).json({error:'Missing order data'});
  const info=db.prepare(`INSERT INTO orders(customer_name,phone,address,city,delivery,payment,items,total)
    VALUES(?,?,?,?,?,?,?,?)`).run(customer_name,phone,address,city,delivery||'Standard',payment||'COD',JSON.stringify(items),Number(total)||0);
  res.json({ok:true,id:info.lastInsertRowid});
});
app.post('/api/admin/login',(req,res)=>{
  if(req.body.username===ADMIN_USER && req.body.password===ADMIN_PASS)
    return res.json({token:jwt.sign({role:'admin'},JWT_SECRET,{expiresIn:'7d'})});
  res.status(401).json({error:'Invalid login'});
});
app.get('/api/admin/stats',auth,(req,res)=>{
  const orders=db.prepare('SELECT * FROM orders ORDER BY id DESC').all();
  const revenue=orders.filter(o=>o.status!=='cancelled').reduce((s,o)=>s+o.total,0);
  res.json({
    revenue, orders:orders.length,
    pending:orders.filter(o=>['new','confirmed','preparing'].includes(o.status)).length,
    delivered:orders.filter(o=>o.status==='delivered').length,
    products:db.prepare('SELECT COUNT(*) c FROM products').get().c,
    customers:new Set(orders.map(o=>o.phone)).size,
    ordersList:orders
  });
});
app.get('/api/admin/products',auth,(req,res)=>res.json(db.prepare('SELECT * FROM products ORDER BY id DESC').all()));
app.post('/api/admin/products',auth,upload.single('image'),(req,res)=>{
  const p=req.body;
  const image=req.file?'/uploads/'+req.file.filename:(p.image||'');
  const r=db.prepare(`INSERT INTO products(name,brand,category,price,old_price,stock,description,image,featured)
    VALUES(?,?,?,?,?,?,?,?,?)`).run(p.name,p.brand||'',p.category||'Maquillage',+p.price,+p.old_price||0,+p.stock||0,p.description||'',image,p.featured==='1'?1:0);
  res.json({ok:true,id:r.lastInsertRowid});
});
app.put('/api/admin/products/:id',auth,upload.single('image'),(req,res)=>{
  const p=req.body; const old=db.prepare('SELECT image FROM products WHERE id=?').get(req.params.id);
  const image=req.file?'/uploads/'+req.file.filename:(p.image||old?.image||'');
  db.prepare(`UPDATE products SET name=?,brand=?,category=?,price=?,old_price=?,stock=?,description=?,image=?,featured=? WHERE id=?`)
   .run(p.name,p.brand||'',p.category||'Maquillage',+p.price,+p.old_price||0,+p.stock||0,p.description||'',image,p.featured==='1'?1:0,req.params.id);
  res.json({ok:true});
});
app.delete('/api/admin/products/:id',auth,(req,res)=>{db.prepare('DELETE FROM products WHERE id=?').run(req.params.id);res.json({ok:true})});
app.get('/api/admin/orders',auth,(req,res)=>res.json(db.prepare('SELECT * FROM orders ORDER BY id DESC').all()));
app.patch('/api/admin/orders/:id',auth,(req,res)=>{
  db.prepare('UPDATE orders SET status=? WHERE id=?').run(req.body.status,req.params.id);res.json({ok:true});
});
app.get('/api/admin/settings',auth,(req,res)=>res.json(settings()));
app.put('/api/admin/settings',auth,(req,res)=>{
  const up=db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
  for(const [k,v] of Object.entries(req.body)) up.run(k,String(v));
  res.json({ok:true});
});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log('Luxe_line_2 Premium running on http://localhost:'+PORT));
